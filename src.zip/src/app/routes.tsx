// URLとPagesの対応

import { createBrowserRouter, Navigate } from 'react-router-dom';
import { Outlet, useParams } from 'react-router-dom';
import { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import HomePage from '../pages/Home/Page';
import WorkDetailPage from '../pages/Works/DitailPage';
import Header from '../components/common/Header';
import Footer from '../components/common/Footer';

function LanguageLayout() {
  const { lang } = useParams<{ lang: string }>();
  const { i18n } = useTranslation();

  useEffect(() => {
    if (lang && (lang === 'ja' || lang === 'en')) {
      i18n.changeLanguage(lang);
    }
  }, [lang, i18n]);

  return (
    <>
      <Header />
      <main>
        <Outlet />
      </main>
      <Footer />
    </>
  );
}

export const router = createBrowserRouter([
  {
    path: '/',
    element: <Navigate to="/ja" replace />,
  },
  {
    path: '/:lang',
    element: <LanguageLayout />,
    children: [
      {
        index: true,
        element: <HomePage />,
      },
      {
        path: 'works/:id',
        element: <WorkDetailPage />,
      },
    ],
  },
], {
  basename: '/portfolio',
});