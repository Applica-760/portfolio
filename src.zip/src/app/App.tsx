// 全てのページで共通する要素の定義，ルーティングの一元化

import { MantineProvider } from '@mantine/core';
import { RouterProvider } from 'react-router-dom';
import { router } from './routes';
import '@mantine/core/styles.css';
import '../styles/App.css';

function App() {
  return (
    <MantineProvider>
      <RouterProvider router={router} />
    </MantineProvider>
  );
}

export default App;
