import { Container, Title, Stack, SimpleGrid } from '@mantine/core';
import { useTranslation } from 'react-i18next';
import WorkCard from '../../components/works/WorkCard';
import ProfileSection from '../../components/profile/ProfileSection';
import { worksList } from '../../contents';

function HomePage() {
  const { t } = useTranslation();

  return (
    <Container size="lg" py="xl">
      {/* 自己紹介セクション */}
      <Stack gap="xl" mb="3rem">
        <ProfileSection />
      </Stack>

      {/* Worksセクション */}
      <Stack gap="lg">
        <Title order={2} size="h3">
          {t('home.works.heading')}
        </Title>
        <SimpleGrid cols={{ base: 1, sm: 2 }} spacing="lg">
          {worksList.map((work) => (
            <WorkCard
              key={work.id}
              work={{
                id: work.id,
                title: t(work.titleKey),
                description: t(work.descriptionKey),
                tags: work.tags,
              }}
            />
          ))}
        </SimpleGrid>
      </Stack>
    </Container>
  );
}

export default HomePage;