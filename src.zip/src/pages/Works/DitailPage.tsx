import { Container, Title, Text } from '@mantine/core';
import { useParams } from 'react-router-dom';

function WorkDetailPage() {
  const { id } = useParams<{ id: string }>();

  return (
    <Container size="lg" py="xl">
      <Title order={1}>Work Detail</Title>
      <Text mt="md">
        Work ID: {id}
      </Text>
    </Container>
  );
}

export default WorkDetailPage;