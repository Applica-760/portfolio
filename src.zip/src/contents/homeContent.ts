// 言語非依存のデータ定義

export interface WorkCardData {
  id: string;
  title: string;
  description: string;
  tags: string[];
}

// 言語非依存のプロジェクトデータ
export interface WorkMetadata {
  id: string;
  titleKey: string;        // 翻訳キー
  descriptionKey: string;  // 翻訳キー
  tags: string[];
}

export const worksList: WorkMetadata[] = [
  {
    id: '1',
    titleKey: 'works.project1.title',
    descriptionKey: 'works.project1.description',
    tags: ['React', 'TypeScript'],
  },
  {
    id: '2',
    titleKey: 'works.project2.title',
    descriptionKey: 'works.project2.description',
    tags: ['Node.js', 'Express'],
  },
  {
    id: '3',
    titleKey: 'works.project3.title',
    descriptionKey: 'works.project3.description',
    tags: ['Python', 'Machine Learning'],
  },
  {
    id: '4',
    titleKey: 'works.project4.title',
    descriptionKey: 'works.project4.description',
    tags: ['Vue.js', 'Firebase'],
  },
];

// 技術スタック（言語非依存）
export const techStack = ['TypeScript', 'React', 'Node.js', 'Python'];