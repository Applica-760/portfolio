// Record the content entity here

export * from './homeContent';