import { Button, Group } from '@mantine/core';
import { useTranslation } from 'react-i18next';
import { useNavigate, useParams, useLocation } from 'react-router-dom';

function LanguageSwitcher() {
  const { i18n } = useTranslation();
  const navigate = useNavigate();
  const location = useLocation();
  const { lang } = useParams<{ lang: string }>();

  const switchLanguage = (newLang: 'ja' | 'en') => {
    i18n.changeLanguage(newLang);
    // location.pathname は basename を除いたパスなので、そのまま言語部分を置き換える
    const newPath = location.pathname.replace(`/${lang}`, `/${newLang}`);
    navigate(newPath);
  };

  return (
    <Group gap="xs">
      <Button
        variant={lang === 'ja' ? 'filled' : 'subtle'}
        size="xs"
        onClick={() => switchLanguage('ja')}
      >
        JP
      </Button>
      <Button
        variant={lang === 'en' ? 'filled' : 'subtle'}
        size="xs"
        onClick={() => switchLanguage('en')}
      >
        EN
      </Button>
    </Group>
  );
}

export default LanguageSwitcher;
