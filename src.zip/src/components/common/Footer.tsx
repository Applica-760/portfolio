// component of Footer

import { Container, Text, Center } from '@mantine/core';
import { useTranslation } from 'react-i18next';

function Footer() {
  const { t } = useTranslation();

  return (
    <footer style={{ borderTop: '1px solid #e0e0e0', marginTop: '2rem' }}>
      <Container size="lg">
        <Center py="xl">
          <Text size="sm" c="dimmed">
            {t('footer.copyright')}
          </Text>
        </Center>
      </Container>
    </footer>
  );
}

export default Footer;