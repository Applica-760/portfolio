import { Paper, Title, Text, Stack, Badge, Group, Anchor } from '@mantine/core';
import { useTranslation, Trans } from 'react-i18next';
import { techStack } from '../../contents';

function ProfileSection() {
  const { t } = useTranslation();
  const careerItems = t('home.profile.career.items', { returnObjects: true }) as string[];

  return (
    <Paper p="xl" radius="md" withBorder>
      <Text mb="lg" component="div">
        <Trans 
          i18nKey="home.profile.bio"
          components={[
            <Anchor href="https://github.com/Applica-760" target="_blank" rel="noopener noreferrer" />
          ]}
        />
      </Text>

      <Title order={3} size="h4" mb="sm">
        {t('home.profile.career.heading')}
      </Title>
      <Stack gap="xs" mb="lg">
        {careerItems.map((item, index) => (
          <Text key={index} size="sm">
            {item}
          </Text>
        ))}
      </Stack>

      <Title order={3} size="h4" mb="sm">
        {t('home.profile.techStack.heading')}
      </Title>
      <Group gap="xs">
        {techStack.map((tech) => (
          <Badge key={tech} size="lg" variant="filled">
            {tech}
          </Badge>
        ))}
      </Group>
    </Paper>
  );
}

export default ProfileSection;